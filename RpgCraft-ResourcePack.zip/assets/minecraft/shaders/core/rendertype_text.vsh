#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat3 IViewRotMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(ModelViewMat, IViewRotMat * Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    // RpgCraft: hide red sidebar score numbers (0xFF5555) drawn at the far right edge of the GUI.
    if (abs(gl_Position.w - 1.0) < 0.0001 && gl_Position.x > 0.88
            && Color.r > 0.99 && abs(Color.g - 0.3333) < 0.01 && abs(Color.b - 0.3333) < 0.01) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    }

    // RpgCraft: 4R-style target panel - text in reserved colors is anchored to the top-right of the screen, its shadow hidden.
    if (abs(gl_Position.w - 1.0) < 0.0001) {
        vec3 c255 = Color.rgb * 255.0;
        if (all(lessThan(abs(c255 - vec3(63.0, 63.0, 62.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(63.0, 56.0, 32.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(63.0, 24.0, 24.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(50.0, 50.0, 49.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(62.0, 63.0, 63.0)), vec3(0.6)))) {
            gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        } else if (all(lessThan(abs(c255 - vec3(252.0, 252.0, 248.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(252.0, 224.0, 128.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(252.0, 96.0, 96.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(200.0, 200.0, 196.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(248.0, 252.0, 252.0)), vec3(0.6)))) {
            gl_Position.x += 1.0 - (184.0 * 0.5 + -21.0) * ProjMat[0][0];
            gl_Position.y += 22.0 * ProjMat[1][1];
            if (all(lessThan(abs(c255 - vec3(252.0, 224.0, 128.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(252.0, 96.0, 96.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(200.0, 200.0, 196.0)), vec3(0.6))) || all(lessThan(abs(c255 - vec3(248.0, 252.0, 252.0)), vec3(0.6)))) gl_Position.z -= 0.002;
        }
    }

    // RpgCraft: HUD frames / bars drawn in reserved colors are pushed back so icons and numbers stay on top; their shadows are hidden.
    if (abs(gl_Position.w - 1.0) < 0.0001) {
        vec3 h255 = Color.rgb * 255.0;
        if (all(lessThan(abs(h255 - vec3(62.0, 62.0, 61.0)), vec3(0.6))) || all(lessThan(abs(h255 - vec3(61.0, 61.0, 60.0)), vec3(0.6)))) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        else if (all(lessThan(abs(h255 - vec3(248.0, 248.0, 244.0)), vec3(0.6)))) gl_Position.z += 0.002;
        else if (all(lessThan(abs(h255 - vec3(244.0, 244.0, 240.0)), vec3(0.6)))) gl_Position.z += 0.001;
    }


    // Each lower HUD panel carries its own frame and content markers.
    if (abs(gl_Position.w - 1.0) < 0.0001) {
        vec3 rgb255 = Color.rgb * 255.0;
        bool leftFrame = all(lessThan(abs(rgb255 - vec3(252.0, 248.0, 236.0)), vec3(0.6)));
        bool leftBar = all(lessThan(abs(rgb255 - vec3(248.0, 244.0, 232.0)), vec3(0.6)));
        bool leftNumber = all(lessThan(abs(rgb255 - vec3(240.0, 248.0, 228.0)), vec3(0.6)));
        bool leftNumberShadow = all(lessThan(abs(rgb255 - vec3(60.0, 62.0, 57.0)), vec3(0.6)));
        bool rightFrame = all(lessThan(abs(rgb255 - vec3(244.0, 252.0, 244.0)), vec3(0.6)));
        bool rightContent = all(lessThan(abs(rgb255 - vec3(240.0, 252.0, 240.0)), vec3(0.6)));
        bool rightContentShadow = all(lessThan(abs(rgb255 - vec3(60.0, 63.0, 60.0)), vec3(0.6)));
        bool backgroundShadow = all(lessThan(abs(rgb255 - vec3(63.0, 62.0, 59.0)), vec3(0.6)))
            || all(lessThan(abs(rgb255 - vec3(62.0, 61.0, 58.0)), vec3(0.6)))
            || all(lessThan(abs(rgb255 - vec3(61.0, 63.0, 61.0)), vec3(0.6)));
        bool left = leftFrame || leftBar || leftNumber || leftNumberShadow;
        bool right = rightFrame || rightContent || rightContentShadow;
        if (backgroundShadow) {
            gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        } else if (left || right) {
            float guiWidth = 2.0 / ProjMat[0][0];
            float hotbarClearance = guiWidth < 448.0 ? 22.0 : 0.0;
            float margin = 4.0;
            float leftBadgeOffset = 219.0;
            float rightFrameEnd = 95.0 + 128.0;
            if (left) {
                gl_Position.x += -1.0 + (leftBadgeOffset + margin) * ProjMat[0][0];
            } else {
                gl_Position.x += 1.0 - (rightFrameEnd + margin) * ProjMat[0][0];
            }
            gl_Position.y -= (4.0 + hotbarClearance) * ProjMat[1][1];
            vec3 light = texelFetch(Sampler2, UV2 / 16, 0).rgb;
            vertexColor.rgb = light * ((leftNumberShadow || rightContentShadow) ? 0.25 : 1.0);
            if (leftFrame || rightFrame) gl_Position.z += 0.002;
            if (leftBar) gl_Position.z += 0.001;
        }
    }
}
